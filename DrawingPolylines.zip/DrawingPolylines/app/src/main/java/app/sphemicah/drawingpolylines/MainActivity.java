package app.sphemicah.drawingpolylines;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import app.sphemicah.drawingpolylines.models.Route;
import app.sphemicah.drawingpolylines.models.interfaces.DirectionFinderListener;
import app.sphemicah.drawingpolylines.services.DirectionsFinder;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,GoogleApiClient.OnConnectionFailedListener, DirectionFinderListener {


    private GoogleMap mMap;
    private SupportMapFragment mapFragment;
    private GoogleApiClient mGoogleApiClient;
    private BitmapDescriptor icon,icon_2;
    private String pickup_point="21 Churchill Rd, Stamford Hill, Durban, 4001";
    private String destination="Kolling St, Greyville, Berea, 4001";


    private static final int[] COLORS = new int[]{R.color.colorAccent};

    private List<Marker> originMarkers = null;
    private List<Marker> destinationMarkers =null;
    private List<Polyline> polylinePaths = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MainActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mapFragment = (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.map);
                mapFragment.getMapAsync(MainActivity.this);
            }
        });

        originMarkers = new ArrayList<>();
        destinationMarkers = new ArrayList<>();
        polylinePaths = new ArrayList<>();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        buildGoogleApiClient();
        mMap.getUiSettings().setCompassEnabled(false);
        mMap.getUiSettings().setMapToolbarEnabled(false);
        mMap.getUiSettings().setMyLocationButtonEnabled(false);

        //Executing the Directions API from the background thread
        try {
            new DirectionsFinder(MainActivity.this, pickup_point, destination).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDirectionFinderStart() {
        //When the background task starts
    }

    @Override
    public void onDirectionFinderSuccess(List<Route> routes) {

        icon = BitmapDescriptorFactory.fromResource(R.mipmap.ic_user_marker);
        icon_2 = BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_dot);

        for (Route route:routes){

            //Set the pickup marker
            originMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(icon)
                    .title(route.startAddress)
                    .position(route.startLocation)));

            //Set the destination marker
            destinationMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(icon_2)
                    .title(route.endAddress)
                    .position(route.endLocation)));

            //Add style to the polylines
            PolylineOptions polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(getResources().getColor(COLORS[0]))
                    .width(10);

            //Draw the polylines to map
            for (int i = 0; i < route.points.size(); i++) {
                polylineOptions.add(route.points.get(i));
                polylinePaths.add(mMap.addPolyline(polylineOptions));
            }

            //Zoom on to the markers
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            Marker [] markers={originMarkers.get(0),destinationMarkers.get(0)};
            for (Marker marker: markers){
                builder.include(marker.getPosition());
            }

            LatLngBounds bounds = builder.build();
            int padding = 150;//150
            CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds,padding);
            mMap.moveCamera(cu);


        }

    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient=new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }
}
