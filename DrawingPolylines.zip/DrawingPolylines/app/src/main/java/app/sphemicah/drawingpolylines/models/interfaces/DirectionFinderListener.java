package app.sphemicah.drawingpolylines.models.interfaces;



import java.util.List;

import app.sphemicah.drawingpolylines.models.Route;

public interface DirectionFinderListener {

    void onDirectionFinderStart();
    void onDirectionFinderSuccess(List<Route> route);
}
